from django.contrib import admin
from unfold.admin import ModelAdmin
from . import models
from django.utils.html import format_html
from django.contrib.auth.models import User, Group

admin.site.unregister(User)
admin.site.unregister(Group)

BOT_TOKEN = models.BotToken.objects.get(user='Admin').token
SEND_MESSAGE_URL = f'https://api.telegram.org/bot{BOT_TOKEN}/sendMessage'

@admin.register(models.ChanelGroup)
class chanel_group(ModelAdmin):
    list_display = ('group_name', 'group_id', 'group_url')

@admin.register(models.BotToken)
class Bot_Token(ModelAdmin):
    exclude = ('user',)  # Исключаем поле user из формы
    list_display = ('user','user_name','token',)  # Не показываем поле user в списке
    def has_add_permission(self, request):
        return True  # Запрещаем добавление
    def has_delete_permission(self, request, obj=None):
        return True  # Запрещаем удаление

@admin.register(models.BotMessage)
class Bot_Message(ModelAdmin):
    readonly_fields = ('command',)
    list_display = ('command', 'text', 'photo')
    def has_add_permission(self, request):
        return True  # Запрещаем добавление
    def has_delete_permission(self, request, obj=None):
        return True  # Запрещаем удаление 

@admin.register(models.BotButtonInline)
class Bot_Button_Inline(ModelAdmin):
    exclude = ('could',)
    list_display = ('display_message', 'text', 'callback_data')
    readonly_fields = ('display_message', 'callback_data')
    def has_delete_permission(self, request, obj=None):
        # Разрешить удаление только если could == True
        if obj and not obj.could:
            return False
        return super().has_delete_permission(request, obj)
    def display_message(self, obj):
        # Форматируем строку без ссылки
        return format_html('<span>{}</span>', obj.message)
    display_message.short_description = 'Message'
    def get_readonly_fields(self, request, obj=None):
        # Делаем поля только для чтения, если объект уже существует
        if obj:  # Если объект существует (при редактировании)
            return ['display_message', 'callback_data',]  # Указываем, что оба поля readonly
        return []
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related('message')  # Используем join для поля 'message'
    def get_fields(self, request, obj=None):
        # Удаляем поле 'message' из отображаемых полей, оставляя только 'display_message'
        fields = super().get_fields(request, obj)
        if obj:  # Если объект существует, убираем поле 'message'
            fields.remove('message')  # Убираем поле 'message' для редактирования
        return fields

@admin.register(models.BotButtonReply)
class Bot_Reply(ModelAdmin):
    readonly_fields = ('message',)
    list_display = ('message', 'text')

    def has_add_permission(self, request):
        return True  # Запрещаем добавление

    def has_delete_permission(self, request, obj=None):
        return True  # Запрещаем удаление
