from django.db import models

class ChanelGroup(models.Model):
    group_name = models.CharField(max_length=100,verbose_name='Channel Is\'mi')
    group_id = models.BigIntegerField(verbose_name='Channel id')
    group_url = models.CharField(max_length=200,verbose_name='Channel url')
    
    def __str__(self) -> str:
        return self.group_name
    
    class Meta:
        verbose_name = 'Channel and Group'
        verbose_name_plural ='Channels and Groups'

class BotToken(models.Model):
    user = models.CharField(max_length=50,unique=True)
    user_id = models.BigIntegerField(verbose_name='Sizning telegram id')
    user_name = models.CharField(max_length=100,verbose_name='I\'smingiz')
    user_url = models.CharField(max_length=100,verbose_name='telegram username')
    token = models.TextField(verbose_name='Bot Token')

    def __str__(self) -> str:
        return self.user
    
    class Meta:
        verbose_name = 'Setting Bot'
        verbose_name_plural ='Settings Bots'

class BotMessage(models.Model):
    command = models.CharField(max_length=50, unique=True)
    text = models.TextField(verbose_name='Malumotlar')
    photo = models.ImageField(upload_to='media/',null=True,blank=True)
    
    def __str__(self) -> str:
        return self.command
    
    class Meta:
        verbose_name = 'Message Bot'
        verbose_name_plural ='Messages Bots'

class BotButtonInline(models.Model):
    message = models.ForeignKey(BotMessage, on_delete=models.CASCADE, related_name='inline',verbose_name='Command')
    text = models.CharField(max_length=100,verbose_name='Knopkanin nomi')
    callback_data = models.CharField(max_length=100)
    could = models.BooleanField(default=True)
    
    def __str__(self):
        return self.text
    
    class Meta:
        verbose_name = 'Inline Knopka'
        verbose_name_plural ='Iniles Knopkalar'

class BotButtonReply(models.Model):
    message = models.ForeignKey(BotMessage, on_delete=models.CASCADE, related_name='reply',verbose_name='Command')
    text = models.CharField(max_length=100,verbose_name='Knopkani nomi')

    def __str__(self):
        return self.text
    
    class Meta:
        verbose_name = 'Reply Knopka'
        verbose_name_plural ='Replys Knopkalar'
