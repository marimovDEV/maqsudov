import os
import django
from aiogram import Router,F
from aiogram.fsm.context import FSMContext
from aiogram.filters.command import CommandStart
from aiogram.types import Message,CallbackQuery

from asgiref.sync import sync_to_async
from ...filters.chat_type import chat_type_filter,send_bot_message,CheckSubChanel,CheckSubChanelCall
from ...states.user_state import UserStates

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'your_project.settings')
django.setup()

user_private_router = Router()
user_private_router.message.filter(
    chat_type_filter(['private']),
    CheckSubChanel(),
    CheckSubChanelCall(),
)

@user_private_router.message(CommandStart())
async def private_start(message:Message,state:FSMContext):
    pass

@user_private_router.callback_query(F.data=='chanel_sub',CheckSubChanelCall(),)
async def admin(call:CallbackQuery,state:FSMContext):
    pass
